﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EntityFrameworkExample1.Migrations
{
    public partial class Migration2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
